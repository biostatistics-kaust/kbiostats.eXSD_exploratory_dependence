correlation <- function(data){
    M <- cor(data)
    M
}

