
External data should be in inst/extdata
and it can be accessed with instructions like
system.file("extdata", "mydataset.csv", package="DEXplorer")
  
